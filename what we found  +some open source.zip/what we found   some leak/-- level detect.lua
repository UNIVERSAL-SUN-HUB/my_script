-- level detect
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

-- Safely wait for the level folder and value to load
local levelData = LocalPlayer:WaitForChild("Data"):WaitForChild("Level")
local currentLevel = levelData.Value

print("Your current level is: " .. tostring(currentLevel))
