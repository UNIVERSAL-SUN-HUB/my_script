-- this is to check quest active or not and status only for sea 3
-- Fix: Make sure the Core table exists before adding the function
local Core = Core or {}

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

function Core:GetQuestData()
    local mainGui = LocalPlayer.PlayerGui:FindFirstChild("Main")
    local questGui = mainGui and mainGui:FindFirstChild("Quest")
    
    -- Check if quest UI exists and is open
    if not questGui or not questGui.Visible then 
        return nil 
    end
    
    local questData = {
        MonsterName = "None",
        CurrentKills = 0,
        MaxKills = 0
    }
    
    -- Loop through the elements inside the Quest UI
    for _, child in ipairs(questGui:GetDescendants()) do
        if child:IsA("TextLabel") and child.Name == "Title" then
            -- Use string matching to parse: "Defeat 8 Cocoa Warriors (0/8)"
            local count, name, current, max = string.match(child.Text, "Defeat (%d+) (.-) %((%d+)/(%d+)%)")
            
            if name and current and max then
                questData.MonsterName = name
                questData.CurrentKills = tonumber(current)
                questData.MaxKills = tonumber(max)
                break -- Data found, exit loop safely
            end
        end
    end
    
    return questData
end

-- Safely run the check
local myQuest = Core:GetQuestData()
if myQuest then
    print("--- Quest Parsed Successfully ---")
    print("Target Mob Name:", myQuest.MonsterName)  
    print("Current Progress:", myQuest.CurrentKills) 
    print("Target Total:", myQuest.MaxKills)        
else
    print("No active quest detected right now.")
end
