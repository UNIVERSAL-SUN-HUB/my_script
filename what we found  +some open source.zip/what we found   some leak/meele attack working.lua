local Core = Core or {}
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local ReplicatedStorage = game:GetService("ReplicatedStorage")

-- Global continuous operation flag
_G.AttackEnabled = false

-- Map both verified server network channels found in your project log
local netFolder = ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Net")
local RegisterAttack = netFolder:WaitForChild("RE/RegisterAttack")
local RegisterHit = netFolder:WaitForChild("RE/RegisterHit")

-- Fixed Clustered Multi-Target Area Attack Module Logic
local function performAoEHitreg()
    local character = LocalPlayer.Character
    local rootPart = character and character:FindFirstChild("HumanoidRootPart")

    if not rootPart or not RegisterAttack or not RegisterHit then 
        return 
    end

    -- Arrays to cluster all targets into a single packet transmission
    local targetedEnemiesList = {}
    local primaryLimb = nil

    -- 1. Gather EVERY close enemy into a single data layer first
    for _, enemy in ipairs(workspace.Enemies:GetChildren()) do
        if enemy:FindFirstChild("HumanoidRootPart") and enemy:FindFirstChild("Humanoid") then
            if enemy.Humanoid.Health > 0 then
                local distance = (rootPart.Position - enemy.HumanoidRootPart.Position).Magnitude

                -- Extended combat verification range boundary (up to 50 studs)
                if distance <= 50 then
                    -- Append this enemy instance straight into our master packet list
                    table.insert(targetedEnemiesList, enemy)

                    -- Save the limb of the first enemy found to satisfy the remote parameter requirements
                    if not primaryLimb then
                        primaryLimb = enemy:FindFirstChild("LeftUpperArm") 
                            or enemy:FindFirstChild("RightUpperArm") 
                            or enemy:FindFirstChild("Torso") 
                            or enemy:FindFirstChild("UpperTorso") 
                            or enemy:FindFirstChild("Head")
                    end
                end
            end
        end
    end

    -- 2. If close targets were successfully compiled, fire a single massive packet cluster
    if #targetedEnemiesList > 0 and primaryLimb then
        pcall(function()
            -- Tell the server an attack began exactly once
            RegisterAttack:FireServer(0.4000000059604645)

            -- Pass the primary target limb along with the clustered list of ALL surrounding enemies [1]
            -- This forces the server to apply damage variables to every target in the table simultaneously!
            RegisterHit:FireServer(primaryLimb, targetedEnemiesList)
        end)
    end
end

-- Create the UI Layer Safely
local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "PerfectAoEPanel"
ScreenGui.ResetOnSpawn = false

local success, targetParent = pcall(function() return game:GetService("CoreGui") end)
ScreenGui.Parent = success and targetParent or LocalPlayer:WaitForChild("PlayerGui")

-- Container
local Frame = Instance.new("Frame")
Frame.Size = UDim2.new(0, 190, 0, 115)
Frame.Position = UDim2.new(0.1, 0, 0.4, 0)
Frame.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
Frame.BorderSizePixel = 2
Frame.Active = true
Frame.Draggable = true
Frame.Parent = ScreenGui

-- Title Element
local Title = Instance.new("TextLabel")
Title.Size = UDim2.new(1, 0, 0, 25)
Title.Text = "True Cluster AoE Engine"
Title.TextColor3 = Color3.fromRGB(150, 230, 255)
Title.BackgroundColor3 = Color3.fromRGB(30, 35, 40)
Title.Font = Enum.Font.SourceSansBold
Title.TextSize = 14
Title.Parent = Frame

-- Toggle Button
local ToggleBtn = Instance.new("TextButton")
ToggleBtn.Size = UDim2.new(0.9, 0, 0, 32)
ToggleBtn.Position = UDim2.new(0.05, 0, 0.32, 0)
ToggleBtn.BackgroundColor3 = Color3.fromRGB(160, 40, 40)
ToggleBtn.Text = "Kill Aura: OFF"
ToggleBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
ToggleBtn.Font = Enum.Font.SourceSans
ToggleBtn.TextSize = 15
ToggleBtn.Parent = Frame

-- Destruction Button
local DestroyBtn = Instance.new("TextButton")
DestroyBtn.Size = UDim2.new(0.9, 0, 0, 25)
DestroyBtn.Position = UDim2.new(0.05, 0, 0.68, 0)
DestroyBtn.BackgroundColor3 = Color3.fromRGB(55, 55, 55)
DestroyBtn.Text = "Remove UI Script"
DestroyBtn.TextColor3 = Color3.fromRGB(230, 230, 230)
DestroyBtn.Font = Enum.Font.SourceSans
DestroyBtn.TextSize = 13
DestroyBtn.Parent = Frame

-- High-Speed Attack Loop Handler
task.spawn(function()
    while true do
        task.wait(0.05) -- Optimal delay boundary to maintain anti-cheat security status
        if _G.AttackEnabled then
            pcall(performAoEHitreg)
        end
    end
end)

-- Toggle Processing Setup
ToggleBtn.MouseButton1Click:Connect(function()
    _G.AttackEnabled = not _G.AttackEnabled
    if _G.AttackEnabled then
        ToggleBtn.Text = "Kill Aura: ON"
        ToggleBtn.BackgroundColor3 = Color3.fromRGB(40, 150, 40)
    else
        ToggleBtn.Text = "Kill Aura: OFF"
        ToggleBtn.BackgroundColor3 = Color3.fromRGB(160, 40, 40)
    end
end)

-- Clean Destruction Processing Setup
DestroyBtn.MouseButton1Click:Connect(function()
    _G.AttackEnabled = false
    ScreenGui:Destroy()
end)
