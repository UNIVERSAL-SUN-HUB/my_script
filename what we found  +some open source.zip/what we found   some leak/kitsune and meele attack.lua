local Core = Core or {}
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local VirtualUser = game:GetService("VirtualUser")
local TweenService = game:GetService("TweenService")

-- Global continuous operation flags
_G.AttackEnabled = false
local currentTween = nil
local selectedPlayerName = nil

-- Map your working melee paths perfectly
local netFolder = ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Net")
local RegisterAttack = netFolder:FindFirstChild("RE/RegisterAttack") or netFolder:WaitForChild("RE/RegisterAttack", 2)
local RegisterHit = netFolder:FindFirstChild("RE/RegisterHit") or netFolder:WaitForChild("RE/RegisterHit", 2)

-- Combined Multi-Target Universal Combat Engine
local function performUniversalAura()
    local character = LocalPlayer.Character
    local rootPart = character and character:FindFirstChild("HumanoidRootPart")
    local activeTool = character and character:FindFirstChildOfClass("Tool")

    if not rootPart then return end

    local targetedEnemiesList = {}
    local primaryLimb = nil

    for _, enemy in ipairs(workspace.Enemies:GetChildren()) do
        if enemy:FindFirstChild("HumanoidRootPart") and enemy:FindFirstChild("Humanoid") and enemy.Humanoid.Health > 0 then
            local distance = (rootPart.Position - enemy.HumanoidRootPart.Position).Magnitude

            if distance <= 55 then
                table.insert(targetedEnemiesList, enemy)
                if not primaryLimb then
                    primaryLimb = enemy:FindFirstChild("LeftUpperArm") 
                        or enemy:FindFirstChild("RightUpperArm") 
                        or enemy:FindFirstChild("Torso")
                end
            end
        end
    end

    if #targetedEnemiesList > 0 then
        -- PATH A: Kitsune / Fruit Transformation (Hitbox + Magnet Method)
        if activeTool == nil or string.find(string.lower(activeTool.Name), "kitsune") or string.find(string.lower(activeTool.Name), "fruit") then
            for _, enemy in ipairs(targetedEnemiesList) do
                pcall(function()
                    enemy.HumanoidRootPart.CFrame = rootPart.CFrame * CFrame.new(0, 0, -3)
                    enemy.Humanoid.PlatformStand = true
                end)
            end
            pcall(function()
                VirtualUser:CaptureController()
                VirtualUser:ClickButton1(Vector2.new(0, 0))
                if activeTool then activeTool:Activate() end
            end)

        -- PATH B: Standard Melee / Weapons (Clustered Packet Method)
        elseif RegisterAttack and RegisterHit and primaryLimb then
            pcall(function()
                RegisterAttack:FireServer(0.4000000059604645)
                RegisterHit:FireServer(primaryLimb, targetedEnemiesList)
            end)
        end
    end
end

-- Fixed Constant 150 Speed Tween Function
local function tweenToTargetCFrame(targetCFrame)
    local rootPart = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
    if not rootPart then return end

    if currentTween then currentTween:Cancel() end

    local distance = (rootPart.Position - targetCFrame.Position).Magnitude
    local duration = distance / 150 -- Time = Distance / Speed forces 150 speed

    local info = TweenInfo.new(duration, Enum.EasingStyle.Linear)
    currentTween = TweenService:Create(rootPart, info, {CFrame = targetCFrame})
    currentTween:Play()
    return currentTween
end

-- Create UI
local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "UltimateMultiPanel"
ScreenGui.ResetOnSpawn = false

local success, targetParent = pcall(function() return game:GetService("CoreGui") end)
ScreenGui.Parent = success and targetParent or LocalPlayer:WaitForChild("PlayerGui")

-- Larger Main Container
local Frame = Instance.new("Frame")
Frame.Size = UDim2.new(0, 210, 0, 270)
Frame.Position = UDim2.new(0.1, 0, 0.3, 0)
Frame.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
Frame.BorderSizePixel = 2
Frame.Active = true
Frame.Draggable = true
Frame.Parent = ScreenGui

-- Title
local Title = Instance.new("TextLabel")
Title.Size = UDim2.new(1, 0, 0, 25)
Title.Text = "Universal Panel V6"
Title.TextColor3 = Color3.fromRGB(200, 230, 255)
Title.BackgroundColor3 = Color3.fromRGB(35, 35, 45)
Title.Font = Enum.Font.SourceSansBold
Title.TextSize = 14
Title.Parent = Frame

-- Section 1: Combat Trigger Toggle Button
local ToggleBtn = Instance.new("TextButton")
ToggleBtn.Size = UDim2.new(0.9, 0, 0, 32)
ToggleBtn.Position = UDim2.new(0.05, 0, 0.12, 0)
ToggleBtn.BackgroundColor3 = Color3.fromRGB(160, 40, 40)
ToggleBtn.Text = "Aura Attack: OFF"
ToggleBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
ToggleBtn.Font = Enum.Font.SourceSansBold
ToggleBtn.TextSize = 14
ToggleBtn.Parent = Frame

-- Section 2: Dropdown Text Display Label
local SelectDisplay = Instance.new("TextLabel")
SelectDisplay.Size = UDim2.new(0.9, 0, 0, 25)
SelectDisplay.Position = UDim2.new(0.05, 0, 0.28, 0)
SelectDisplay.BackgroundColor3 = Color3.fromRGB(45, 45, 50)
SelectDisplay.Text = "Target: [None Chosen]"
SelectDisplay.TextColor3 = Color3.fromRGB(220, 220, 220)
SelectDisplay.Font = Enum.Font.SourceSans
SelectDisplay.TextSize = 13
SelectDisplay.Parent = Frame

-- Scrolling Container list window for tracking players
local ListScroller = Instance.new("ScrollingFrame")
ListScroller.Size = UDim2.new(0.9, 0, 0, 75)
ListScroller.Position = UDim2.new(0.05, 0, 0.39, 0)
ListScroller.BackgroundColor3 = Color3.fromRGB(20, 20, 22)
ListScroller.CanvasSize = UDim2.new(0, 0, 0, 0)
ListScroller.ScrollBarThickness = 5
ListScroller.Parent = Frame

local uiLayout = Instance.new("UIListLayout")
uiLayout.Padding = UDim.new(0, 2)
uiLayout.Parent = ListScroller

-- Function to loop and populate player entries
local function reloadPlayerSelectionList()
    -- Wipe existing buttons
    for _, obj in ipairs(ListScroller:GetChildren()) do
        if obj:IsA("TextButton") then obj:Destroy() end
    end

    local count = 0
    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= LocalPlayer then
            count = count + 1
            local PBtn = Instance.new("TextButton")
            PBtn.Size = UDim2.new(1, 0, 0, 22)
            PBtn.BackgroundColor3 = Color3.fromRGB(40, 40, 45)
            PBtn.Text = p.DisplayName or p.Name
            PBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
            PBtn.Font = Enum.Font.SourceSans
            PBtn.TextSize = 12
            PBtn.Parent = ListScroller

            PBtn.MouseButton1Click:Connect(function()
                selectedPlayerName = p.Name
                SelectDisplay.Text = "Target: " .. p.Name
            end)
        end
    end
    ListScroller.CanvasSize = UDim2.new(0, 0, 0, count * 24)
end

-- Refresh List Button
local RefreshBtn = Instance.new("TextButton")
RefreshBtn.Size = UDim2.new(0.42, 0, 0, 25)
RefreshBtn.Position = UDim2.new(0.05, 0, 0.70, 0)
RefreshBtn.BackgroundColor3 = Color3.fromRGB(50, 100, 150)
RefreshBtn.Text = "🔄 Refresh"
RefreshBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
RefreshBtn.Font = Enum.Font.SourceSans
RefreshBtn.TextSize = 13
RefreshBtn.Parent = Frame

-- Tween Teleport Button
local TweenBtn = Instance.new("TextButton")
TweenBtn.Size = UDim2.new(0.42, 0, 0, 25)
TweenBtn.Position = UDim2.new(0.53, 0, 0.70, 0)
TweenBtn.BackgroundColor3 = Color3.fromRGB(40, 140, 90)
TweenBtn.Text = "🚀 Tween 150"
TweenBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
TweenBtn.Font = Enum.Font.SourceSansBold
TweenBtn.TextSize = 13
TweenBtn.Parent = Frame

-- Destruction Clean Panel Exit Button
local DestroyBtn = Instance.new("TextButton")
DestroyBtn.Size = UDim2.new(0.9, 0, 0, 25)
DestroyBtn.Position = UDim2.new(0.05, 0, 0.86, 0)
DestroyBtn.BackgroundColor3 = Color3.fromRGB(55, 55, 55)
DestroyBtn.Text = "Remove UI Script"
DestroyBtn.TextColor3 = Color3.fromRGB(230, 230, 230)
DestroyBtn.Font = Enum.Font.SourceSans
DestroyBtn.TextSize = 13
DestroyBtn.Parent = Frame

-- Initialization routines
reloadPlayerSelectionList()

-- Core Fast Attack Loop Execution Handler
task.spawn(function()
    while true do
        task.wait(0.04)
        if _G.AttackEnabled then
            pcall(performUniversalAura)
        end
    end
end)

-- UI Interactive Signal Mapping Assignments
ToggleBtn.MouseButton1Click:Connect(function()
    _G.AttackEnabled = not _G.AttackEnabled
    if _G.AttackEnabled then
        ToggleBtn.Text = "Aura Attack: ON"
        ToggleBtn.BackgroundColor3 = Color3.fromRGB(40, 150, 40)
    else
        ToggleBtn.Text = "Aura Attack: OFF"
        ToggleBtn.BackgroundColor3 = Color3.fromRGB(160, 40, 40)
    end
end)

RefreshBtn.MouseButton1Click:Connect(reloadPlayerSelectionList)

TweenBtn.MouseButton1Click:Connect(function()
    if not selectedPlayerName then 
        SelectDisplay.Text = "Error: Pick a player first!"
        return 
    end

    local targetPlayer = Players:FindFirstChild(selectedPlayerName)
    local targetChar = targetPlayer and targetPlayer.Character
    local targetHRP = targetChar and targetChar:FindFirstChild("HumanoidRootPart")

    if targetHRP then
        SelectDisplay.Text = "Tweening to " .. selectedPlayerName .. "..."
        tweenToTargetCFrame(targetHRP.CFrame)
    else
        SelectDisplay.Text = "Error: Target is dead/unloaded"
    end
end)

DestroyBtn.MouseButton1Click:Connect(function()
    _G.AttackEnabled = false
    if currentTween then currentTween:Cancel() end
    ScreenGui:Destroy()
end)
